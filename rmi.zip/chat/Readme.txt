Instructions:

1. Compile everything (javac *.java)

2. Move files: 
   ChatServer.class  ChatServerImpl.class  ChatClient.class Message.class
   in a directory called "server"

3. Move files:
   ChatServer.class  ChatClient.class  ChatClientImpl.class  Message.class MyMessage.class
   in a directory called "client"

4. run "rmiregistry" under server

5. run "java -Djava.security.policy=myPolicy -Djava.rmi.server.hostname=127.0.0.1 -Djava.rmi.server.useCodebaseOnly=false ChatServerImpl" under server

6. run "java -Djava.security.policy=myPolicy -Djava.rmi.server.hostname=127.0.0.1 ChatClientImpl localhost" under client

7. write a message and... get the exception

8. Repeat points 4 and 5

9. run "java -Djava.security.policy=myPolicy -Djava.rmi.server.hostname=127.0.0.1 -Djava.rmi.server.codebase=file:/path_to_the_client_dir/ ChatClientImpl localhost" under client

10. send a message and... it works

Possible problems:

- Be sure the url in 9 is correcty entered and ends with a slash. It must
  point (full path) to the directory where the client classes have been copied
  ("client" in the discussion above).

- The above code works only with Java < 17. Latest versions deprecate the
  SecurityManager and do not allow class loading.
