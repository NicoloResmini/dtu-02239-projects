import java.io.*;

public interface Message extends Serializable {
    public String getContent();
}
